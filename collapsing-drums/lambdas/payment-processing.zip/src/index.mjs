import mysql from 'mysql2/promise';
  
  let connection; 
  
  const dbConfig = {
      host: "collapsingdrumsdb.c14wko0uu54z.us-east-2.rds.amazonaws.com",
      user: "admin",
      password: "collapsing-drums",
      database: "collaspingdrumsDB",
      port: 3306
  }
  
  // Check if connection is initialized
  const getConnection = async () => {
      if (!connection || connection.state === 'disconnected'){
          connection = await mysql.createConnection(dbConfig);
      }
      return connection;
  };
  
export const handler = async (event) => {
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
    };
    
    let paymentId = 0;

    try {
        // Parse  payment details from the request body
        const order = JSON.parse(event.body); 

        connection = await getConnection();

        const [payment] = await connection.execute(
            'INSERT INTO Payment_Info (credit_card_number, expiration_date, cvv, card_holder_name) VALUES (?, ?, ?, ?)',
            [order.credit_card_number, order.expir_date, order.cvvCode, order.card_holder_name]
        );
        paymentId = payment.insertId;

        // Return a successful response with the confirmation token
        return {
            statusCode: 200,
            headers: headers,
            body: JSON.stringify({
                message: "Payment processed successfully",
                confirmationToken: paymentId,
            }),
        };
    } catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            headers: headers,
            body: JSON.stringify({
                message: "Failed to process payment " + error.toString(),
                confirmationToken: paymentId
            }),
        };
    }
};
