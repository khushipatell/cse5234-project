import mysql from 'mysql2/promise';
  
  let connection; 
  
  const dbConfig = {
      host: "collapsingdrumsdb.c14wko0uu54z.us-east-2.rds.amazonaws.com",
      user: "admin",
      password: "collapsing-drums",
      database: "collaspingdrumsDB",
      port: 3306
  }
  
  // Check if connection is initialized
  const getConnection = async () => {
      if (!connection || connection.state === 'disconnected'){
          connection = await mysql.createConnection(dbConfig);
      }
      return connection;
  };
  
export const handler = async (event) => {
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
    };

    try {
        // Parse shipping details from the request body
        const shippingData = JSON.parse(event.detail); 
        const { businessId, address, numberOfPackets, weightPerPacket } = shippingData;

        connection = await getConnection();

        const [shipping] = await connection.execute(
            `INSERT INTO Shipping_Orders (business_id, address, number_of_packets, weight_per_packet) VALUES (?, ?, ?, ?)`,
            [businessId, address, numberOfPackets, weightPerPacket]
        );

        const shippingToken = shipping.insertId;

        // Return a successful response with the confirmation token
        return {
            statusCode: 200,
            headers: headers,
            body: JSON.stringify({
                message: "Shipping processed successfully",
            }),
            shippingToken: shippingToken
        };
    } catch (error) {
        return {
            statusCode: 500,
            headers: headers,
            body: JSON.stringify({
                message: "Failed to process shipping: " + error.toString(),
            }),
        };
    }
};
