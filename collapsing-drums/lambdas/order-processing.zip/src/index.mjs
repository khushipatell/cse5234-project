import mysql from 'mysql2/promise';
import AWS from 'aws-sdk';
const eventBridge = new AWS.EventBridge();
  
  let connection; 
  
  const dbConfig = {
      host: "collapsingdrumsdb.c14wko0uu54z.us-east-2.rds.amazonaws.com",
      user: "admin",
      password: "collapsing-drums",
      database: "collaspingdrumsDB",
      port: 3306
  }
  
  // Check if connection is initialized
  const getConnection = async () => {
      if (!connection || connection.state === 'disconnected'){
          connection = await mysql.createConnection(dbConfig);
      }
      return connection;
  };
  
// Function to fetch inventory directly from the database
const fetchInventoryFromDB = async (productIds) => {
    connection = await getConnection();

    // Fetch available quantity for each product ID
    const [rows] = await connection.query(
        'SELECT id, quantity FROM Merch WHERE id IN (?)',
        [productIds]
    );
    
    console.log("Inventory Data:", rows); // Log inventory data to ensure it's being fetched correctly

    const inventoryMap = {};
    rows.forEach(row => {
        inventoryMap[row.id] = row.quantity;
    });

    return inventoryMap;
};


export const handler = async (event) => {
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
    };
    try {
        if (!event.body) {
            throw new Error('No body found in the request');
        }

        connection = await getConnection();

        const order = JSON.parse(event.body);
        const [customer_fname, customer_lname] = order.card_holder_name.split(' ');

        // Fetch all product IDs needed from buyQuantity
        const productIds = order.buyQuantity
            .map((_, index) => index + 9)
            .filter((_, index) => order.buyQuantity[index] > 0); // Only include products with a non-zero quantity

        const inventoryMap = await fetchInventoryFromDB(productIds);

        // Check if all items in the order have enough quantity
        let allAvailable = true;
        for (let i = 0; i < order.buyQuantity.length; i++) {
            const orderedQuantity = order.buyQuantity[i];
            const productId = i + 9; 
        
            if (orderedQuantity > 0) {
                const availableQuantity = inventoryMap[productId] || 0; // Default to 0 if no data for product
                console.log(`Checking product ${productId}: Ordered quantity = ${orderedQuantity}, Available quantity = ${availableQuantity}`);
                
                if (availableQuantity < orderedQuantity) {
                    console.log(`Insufficient quantity for product ${productId}`);
                    allAvailable = false;
                    break; // Exit loop once insufficient quantity is found
                }
            }
        }

        // POST API call to Payment-Process
        const getPaymentToken = async () => {
            const response = await fetch('https://0q2mix7rob.execute-api.us-east-2.amazonaws.com/devOrder/payment', {
                method: "POST",
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(order),
            });

            if (!response.ok){
                throw new Error ("http error status is " + response.status); 
            }

            const data = await response.json();
            return data;
        }

        // If quantity is available
        if (allAvailable) {

            // Check for payment token
            let confirmationNumber;
            // Confirm Payment
            const paymentToken = await getPaymentToken();
            if (paymentToken.confirmationToken){
                const confirmationNumber = Math.floor(Math.random() * 1000000000).toString();

                // Insert into DB
                const [shippingResult] = await connection.execute(
                    'INSERT INTO Shipping_Info (address_1, address_2, city, state, zip_code) VALUES (?, ?, ?, ?, ?)',
                    [order.address_1, order.address_2 || null, order.city, order.state, order.zip]
                );
                const shippingId = shippingResult.insertId;

                const [orderResult] = await connection.execute(
                    'INSERT INTO Customer_Order (customer_fname, customer_lname, customer_email, shipping_id, payment_id) VALUES (?, ?, ?, ?, ?)',
                    [customer_fname, customer_lname, order.customer_email, shippingId, paymentToken.confirmationToken]
                );
                const customerOrderId = orderResult.insertId;

                const shipmentDetails = []; // Gets order object for shipment

                for (let i = 0; i < order.buyQuantity.length; i++) {
                    const submittedQuantity = order.buyQuantity[i];
                    if (submittedQuantity > 0) {
                        const productId = i + 9;  // Adjust to start from product ID 9
                        await connection.execute(
                            'INSERT INTO Customer_Order_Line_Item (item_id, submitted_quantity, customer_order_id) VALUES (?, ?, ?)',
                            [productId, submittedQuantity, customerOrderId]  // Insert the correct productId
                        );

                        // Prepare shipment packet details
                        shipmentDetails.push({
                            itemId: i + 1,
                            quantity: submittedQuantity,
                            weight: submittedQuantity * 1.0,
                        });
                    }
                }

                // Publish event to EventBridge
                const eventParams = {
                    Entries: [
                        {
                            Source: 'collapsing-drums.orders',
                            DetailType: 'ShippingOrderCreated',
                            Detail: JSON.stringify({
                                businessId: "12345", // Unique registration ID of your storefront
                                address: `${order.address_1}, ${order.city}, ${order.state} ${order.zip}`,
                                numberOfPackets: shipmentDetails.length,
                                weightPerPacket: shipmentDetails.map(packet => packet.weight),
                            }),
                            EventBusName: 'default',
                        },
                    ],
                };

                const eventBridge = new AWS.EventBridge();

                // putEvents creates the object using eventParams to be sent 
                eventBridge.putEvents(eventParams, (err, data) => {
                    if (err) {
                        console.error("Error sending event to EventBridge:", err);
                    } else {
                        console.log("Event successfully sent to EventBridge:", data);
                    }
                });
                return {
                    statusCode: 200,
                    headers: headers,
                    body: JSON.stringify({
                        message: "Order successfully processed",
                        confirmationNumber: confirmationNumber
                    }),
                };
            } else {
                return {
                    statusCode: 400,
                    headers: headers,
                    body: JSON.stringify({
                        message: "Invalid payment process " + paymentToken.confirmationToken
                    }),
                };
            }
        } else {
            return {
                statusCode: 400,
                headers: headers,
                body: JSON.stringify({
                    message: "Insufficient quantity for one or more items"
                }),
            };
        }
    } catch (error) {
        return {
            statusCode: 500,            
            headers: headers,
            body: JSON.stringify({
                message: "Failed to process the order",
                error: error.message,
                stack: error.stack
            }),
        };
    }
};
