import mysql from 'mysql2/promise';

let connection; 

const dbConfig = {
    host: "collapsingdrumsdb.c14wko0uu54z.us-east-2.rds.amazonaws.com",
    user: "admin",
    password: "collapsing-drums",
    database: "collaspingdrumsDB",
    port: 3306
}

// Check if connection is initialized
const getConnection = async () => {
    if (!connection || connection.state === 'disconnected'){
        connection = await mysql.createConnection(dbConfig);
    }
    return connection;
};

async function testConnection() {
    try {
        const connection = await mysql.createConnection(dbConfig);
        console.log("Connection successful!");
        await connection.end();
    } catch (error) {
        console.error("Connection failed:", error.message);
    }
}

testConnection();

export const handler = async (event) => {
    let response;

    // try to connect to DB
    try {
        const connection = await getConnection();

        //If path parameter exists and it is a number, fetch specific product by id
        if (event.pathParameters && !isNaN(event.pathParameters.id)) {
            const [rows] = await connection.execute("SELECT * FROM Merch WHERE id = ?", [event.pathParameters.id]);

            //Ensure product is found
            if (rows.length > 0) {
                response = { statusCode: 200, body: JSON.stringify(rows[0]) };
            } else {
                response = { statusCode: 404, body: "Product not found." };
            }

        // If path parameter id is 'id', feth all products    
        } else if (event.pathParameters && event.pathParameters.id === 'id') {
            const [rows] = await connection.execute("SELECT * FROM Merch");
            response = { statusCode: 200, body: JSON.stringify(rows) };
        
        // Handle invalid paths
        } else {
            response = { statusCode: 404, body: "Invalid path." };
        }

    } catch (error) {
        console.error(error);
        response = { statusCode: 500, body: "Server Error: " + error.message};
    }

    // Set CORS headers
    response['headers'] = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type'
    };

    return response;
}